package testing;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.aggregator.ArgumentsAccessor;
import org.junit.jupiter.params.provider.CsvSource;

import controller.OnewayController;

class ControllerTest {

	@ParameterizedTest
	@CsvSource({"10000, 1, 3", "12000, 2, 6", "12000, 6, 2", "20000, 12, 2"})
	void testCalculateCost(ArgumentsAccessor  args) throws Exception {
		OnewayController ow = new OnewayController();
		int cost = args.getInteger(0);
		int enterStation = args.getInteger(1);
		int exitStation = args.getInteger(2);
		assertEquals(cost, ow.calculateCost(enterStation, exitStation));
	}

}
