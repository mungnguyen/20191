/**
 * AFC
 * controller
 * le minh nguyen
 * Dec 6, 2019
 */
package testing;

import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.Mockito.when;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import controller.TwentyfourHourController;
import controller.exception.InvalidEmbarkationTimeException;
import controller.exception.InvalidTicketException;
import controller.exception.WrongDirectionException;
import controller.utility.Utility;
import entity.ticket.TwentyfourHourTicket;

/**
 * @author le minh nguyen
 * @version 1.0
 * Lecture: Nguyen Thi Thu Trang
 * Project: AFC
 * Date: Dec 6, 2019
 * Brief Description: 
 */
class TwentyfourHourControllerTest {

	/**
	 * Test method for {@link controller.TwentyfourHourController#checkEmbarkation(java.lang.String, int)}.
	 * @throws Exception 
	 */
	@Test
	void testCheckEmbarkation() throws Exception {
		TwentyfourHourController tfCtrl = new TwentyfourHourController();
		TwentyfourHourTicket tf1 = new TwentyfourHourTicket("TF201811100001", "out", 1, new Date());
		when(tfCtrl.getTicketInfor("bf3b2290e229da2b")).thenReturn(tf1);
		
		assertThrows(WrongDirectionException.class, ()->tfCtrl.checkEmbarkation("bf3b2290e229da2b", 1));
		
		TwentyfourHourTicket tf2 = new TwentyfourHourTicket("TF201811100001", "in", 1, new Date());
		when(tfCtrl.getTicketInfor("bf3b2290e229da2b")).thenReturn(tf2);
		
		assertDoesNotThrow(()->tfCtrl.checkEmbarkation("bf3b2290e229da2b", 3));
		
	}

	/**
	 * Test method for {@link controller.TwentyfourHourController#checkDisbarkation(java.lang.String, int)}.
	 * @throws Exception 
	 */
	@Test
	void testCheckDisbarkation() throws Exception {
		TwentyfourHourController tfCtrl = new TwentyfourHourController();
		TwentyfourHourTicket tf1 = new TwentyfourHourTicket("TF201811100001", "in", 1, new Date());
		when(tfCtrl.getTicketInfor("bf3b2290e229da2b")).thenReturn(tf1);
		
		assertThrows(WrongDirectionException.class, ()->tfCtrl.checkEmbarkation("bf3b2290e229da2b", 1));
		
		TwentyfourHourTicket tf2 = new TwentyfourHourTicket("TF201811100001", "out", 1, new Date());
		when(tfCtrl.getTicketInfor("bf3b2290e229da2b")).thenReturn(tf2);
		
		assertDoesNotThrow(()->tfCtrl.checkEmbarkation("bf3b2290e229da2b", 3));
	}

	/**
	 * Test method for {@link controller.TwentyfourHourController#checkTime(entity.ticket.TwentyfourHourTicket)}.
	 * @throws Exception 
	 */
	@Test
	void testCheckTime() throws Exception {
		TwentyfourHourController tfCtrl = new TwentyfourHourController();
		TwentyfourHourTicket tf1 = new TwentyfourHourTicket("TF201811100001", "in", 1, 
				Utility.convertStringtoDate("2019-12-06 00:00:00"));
		
		assertThrows(InvalidTicketException.class, ()->tfCtrl.checkTime(tf1));
		
		TwentyfourHourTicket tf2 = new TwentyfourHourTicket("TF201811100001", "in", 2, new Date());
		assertThrows(InvalidTicketException.class, ()->tfCtrl.checkTime(tf2));
		
		// in used
		TwentyfourHourTicket tf3 = new TwentyfourHourTicket("TF201811100001", "in", 1, new Date());
		assertDoesNotThrow(()->tfCtrl.checkTime(tf3));
		
		// new
		TwentyfourHourTicket tf4 = new TwentyfourHourTicket("TF201811100001", "in", 0, Utility.convertStringtoDate("0000-00-00 00:00:00"));
		assertDoesNotThrow(()->tfCtrl.checkTime(tf4));
		
		
		
	}

}
