package testing;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import controller.OnewayController;
import controller.exception.InvalidStationException;
import controller.exception.InvalidTicketException;
import controller.exception.NotEnoughBalanceException;
import controller.exception.WrongDirectionException;
import entity.ticket.OnewayTicket;

class OnewayControllerTest {

	@Test
	void testCheckEnterStation() throws Exception {
		OnewayController owCtrl = new OnewayController();
		OnewayTicket owTK1 = new OnewayTicket("1", "", 10000, 0, 1, 4);
		assertThrows(InvalidStationException.class, ()->owCtrl.checkEnterStation(owTK1, 5));
		
		OnewayTicket owTK2 = new OnewayTicket("1", "out", 10000, 0, 1, 4);
		assertThrows(WrongDirectionException.class, ()->owCtrl.checkEnterStation(owTK2, 3));
		
		OnewayTicket owTK3 = new OnewayTicket("1", "", 10000, 2, 1, 4);
		assertThrows(InvalidTicketException.class, ()->owCtrl.checkEnterStation(owTK3, 3));
		
		OnewayTicket owTK4 = new OnewayTicket("1", "", 8000, 0, 1, 4);
		assertThrows(NotEnoughBalanceException.class, ()->owCtrl.checkEnterStation(owTK4, 3));
		
		OnewayTicket owTK5 = new OnewayTicket("1", "", 10000, 0, 1, 4);
		assertDoesNotThrow(()->owCtrl.checkEnterStation(owTK5, 2));
	}

	@Test
	void testCheckExitStation() throws Exception {
		OnewayController owCtrl = new OnewayController();
		
		OnewayTicket owTK1 = new OnewayTicket("1", "", 10000, 2, 1, 4);
		assertThrows(InvalidTicketException.class, ()->owCtrl.checkExitStation(owTK1, 3));
		
		OnewayTicket owTK2 = new OnewayTicket("1", "in", 10000, 1, 1, 4);
		assertThrows(WrongDirectionException.class, ()->owCtrl.checkExitStation(owTK2, 3));
		
		OnewayTicket owTK3 = new OnewayTicket("1", "out", 10000, 1, 1, 4);
		assertDoesNotThrow(()->owCtrl.checkExitStation(owTK3, 3));
	}

	@Test
	void testCheckExitingBalance() throws Exception {
		OnewayController owCtrl = new OnewayController();
		
		OnewayTicket owTK1 = new OnewayTicket("1", "out", 10000, 1, 1, 4);
		assertThrows(NotEnoughBalanceException.class, ()->owCtrl.checkExitingBalance(owTK1, 1, 12));
	}

}
