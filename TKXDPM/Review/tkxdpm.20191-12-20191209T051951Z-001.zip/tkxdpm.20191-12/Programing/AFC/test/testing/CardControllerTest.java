package testing;

import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import controller.CardController;
import controller.exception.InvalidTicketException;
import controller.exception.NotEnoughBalanceException;
import controller.exception.WrongDirectionException;
import entity.ticket.Card;

class CardControllerTest {
	
	@Test
	void testCheckExitingBalance () throws Exception {
		CardController cardcon = new CardController();
		
		Card card = new Card("1", 50000, 1, "out");
		assertThrows(NotEnoughBalanceException.class, ()->cardcon.checkExitingBalance(card, 60000));
	}
	
	@Test
	void testCheckEnteringBalance() throws Exception {
		CardController cardcon = new CardController();
		
		Card card = new Card("1", 10000, 1, "out");
		assertThrows(NotEnoughBalanceException.class, ()->cardcon.checkEnteringBalance(card));
	}
	
	@Test
	void testCheckEnterStation() throws Exception {
		CardController cardcon = new CardController();
		
		Card card = new Card("1", 100000, 2, "in");
		assertThrows(InvalidTicketException.class, ()->cardcon.checkEnterStation(card));
		
		Card card1 = new Card("1", 100000, 1, "out");
		assertThrows(WrongDirectionException.class, ()->cardcon.checkEnterStation(card1));
	}
	
	void testCheckExitStation() throws Exception {
		CardController cardcon = new CardController();
		
		Card card = new Card("1", 100000, 2, "out");
		assertThrows(InvalidTicketException.class, ()->cardcon.checkEnterStation(card));
		
		Card card1 = new Card("1", 100000, 1, "in");
		assertThrows(WrongDirectionException.class, ()->cardcon.checkEnterStation(card1));
	}
}