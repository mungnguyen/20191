package faking;

import java.time.LocalDate;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang3.StringUtils;
public class FakeData {
	
	private static final AtomicInteger count = new AtomicInteger(0);
	
	public String generateDateOfBirth() {
		Random random = new Random();
		int minDay = (int) LocalDate.of(2018, 1, 1).toEpochDay();
		int maxDay = (int) LocalDate.of(2020, 1, 1).toEpochDay();
		long randomDay = minDay + random.nextInt(maxDay - minDay);

		LocalDate randomBirthDate = LocalDate.ofEpochDay(randomDay);
		return randomBirthDate.toString().replace("-", "");
	}
	
	public void genarateIdTicket(String prefix, int num) {
		for (int i=1; i<=num; i++) {
			String fkDate = generateDateOfBirth();
			System.out.println("(\""  + prefix + fkDate + padNumber(count.incrementAndGet()) + "\", ),");
		}
	}
	
	public String padNumber(int number) {
		return StringUtils.leftPad(String.valueOf(number), 4, "0");
	}
	
	
	public static void main(String[] args) {
		FakeData fk = new FakeData();
		System.out.println(fk.generateDateOfBirth());
		fk.genarateIdTicket("TF", 10);
	}
}
