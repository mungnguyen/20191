package faking;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class NewTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
