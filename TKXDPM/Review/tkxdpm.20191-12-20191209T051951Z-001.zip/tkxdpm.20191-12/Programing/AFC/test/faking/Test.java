package faking;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import controller.Controller;
import controller.OnewayController;
import controller.utility.TypeOfTicket;
import controller.utility.Utility;
import hust.soict.se.customexception.InvalidIDException;
import hust.soict.se.recognizer.TicketRecognizer;
import hust.soict.se.scanner.CardScanner;

public class Test {
	
	private int i=1;
	public static void main(String[] args) throws Exception {

//		Date dt = new Date();
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//		String currentTime = sdf.format(dt);
//		System.out.println(currentTime);
//		Thread.sleep(5000);
//		dt = new Date();
//		currentTime = sdf.format(dt);
//		System.out.println(currentTime);
		Date dt = new Date();
		Thread.sleep(5000);
		Date dt2 = new Date();
		System.out.println(dt2.getTime() - dt.getTime());
		Date new_date = new Date(dt2.getTime() - dt.getTime());
		System.out.println(Utility.convertDateToString(new_date));
		
		

}
}
