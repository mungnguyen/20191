
import java.util.InputMismatchException;
import java.util.Scanner;

import controller.CardController;
import controller.Controller;
import controller.OnewayController;
import controller.TwentyfourHourController;
import controller.exception.InvalidEmbarkationTimeException;
import controller.exception.InvalidStationException;
import controller.exception.InvalidTicketException;
import controller.exception.NotEnoughBalanceException;
import controller.exception.WrongDirectionException;
import controller.utility.CalculatingCostOnLine;
import controller.utility.Direction;
import controller.utility.Utility;
import entity.database.TicketDB;
import hust.soict.se.customexception.InvalidIDException;
import hust.soict.se.gate.Gate;
import hust.soict.se.recognizer.TicketRecognizer;
import hust.soict.se.scanner.CardScanner;
import view.interface_.AFCInterface;



/**
 * @author le minh nguyen
 * @version 1.0
 * Lecture: Nguyen Thi Thu Trang
 * Project: AFC
 * Date: Dec 6, 2019
 * Brief Description: 
 */
public class Main {
	private static AFCInterface afcInterface;
	static Scanner scanner = new Scanner(System.in);
	static String barcode;
	static int station;
	static String direction;
	static String code;
	
	/**
	 * this method gets input from user
	 */
	public static void getInput() {
		System.out.println("----------- Your input ------------");
		System.out.printf("Enter your barcode: ");
		barcode = scanner.next();	
		try {
			System.out.printf("Choose station by id (1->12): ");
			station = scanner.nextInt();
			if (station < 1 || station > 12) {
				throw new InvalidStationException("Invalid input station (must be between (1-12))");
			}
			System.out.printf("Choose direction (in/out): " );
			direction = scanner.next();
			if (!direction.equals(Direction.in) && !direction.equals(Direction.out)) {
				throw new WrongDirectionException(" wrong direction (must be 'in' or 'out')");
			}
		}catch (InputMismatchException e) {
			scanner.nextLine();
			throw new InputMismatchException("Invalid station ID (must be a number between 1-12)");
		}
		
	}
	
	
	public static void main(String[] args) throws Exception {
		CalculatingCostOnLine cal = CalculatingCostOnLine.getInstance();
		while(true) {
			TicketDB.showAllStation();
			Controller.showAllValidTicket();
			try{
				getInput();
				//hash barcode and process input
				switch (Utility.checkTypeOfTicket(barcode)) {
				case card:
					code = CardScanner.getInstance().process(barcode);
					CardController cardController = CardController.getInstance(cal);
					afcInterface = AFCInterface.getInstance(cardController);
					break;
		
				case onewayticket:
					code = TicketRecognizer.getInstance().process(barcode);
					OnewayController owController = OnewayController.getInstance(cal);
					afcInterface = AFCInterface.getInstance(owController);
					break;

				case twentyfourhour:
					code = TicketRecognizer.getInstance().process(barcode);
					TwentyfourHourController twController = TwentyfourHourController.getInstance(cal);
					afcInterface = AFCInterface.getInstance(twController);
					break;
				}
				
				afcInterface.process(code, station, direction);
			}
			catch (InvalidEmbarkationTimeException | InvalidStationException | InvalidTicketException 
				 | NotEnoughBalanceException | WrongDirectionException | InvalidIDException | InputMismatchException e) {
				System.out.println("\n===>>Error: " + e.getMessage());
				Gate.getInstance().close();
			}
			System.out.print("\nDo you want to continue (Y-yes/N-no): ");
			Scanner sc = new Scanner(System.in);
			String input = sc.next();
			while(!input.toUpperCase().equals("Y") && !input.toUpperCase().equals("N")) {
				System.out.println("Invalid option (try again)");
				input = sc.next();
			}
			
			if (input.toUpperCase().equals("N")) {
				System.out.println("Bye bye and see you again");
				break;
			}
		}
	}
}
