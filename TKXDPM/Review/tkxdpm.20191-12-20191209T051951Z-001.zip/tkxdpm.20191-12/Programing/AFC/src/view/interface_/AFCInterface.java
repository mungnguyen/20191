package view.interface_;

import controller.Controller;
import controller.utility.Direction;
import hust.soict.se.gate.Gate;

/**
 * @author le minh nguyen
 * @version 1.0
 * Lecture: Nguyen Thi Thu Trang
 * Project: AFC
 * Date: Dec 6, 2019
 * Brief Description: this class takes responsibility for communicating between external interface and internal system
 */
public class AFCInterface {

	private static Controller controller;
	private static AFCInterface instance;
	
	public AFCInterface() {
		
	}
	
	public static AFCInterface getInstance(Controller controller) {
		AFCInterface.controller = controller;
		if(instance==null) {
			instance = new AFCInterface();
		}
		return instance;
	}
	
	/**
	 * @param code  code of the ticket
	 * @param idStation  id of the station
	 * @param direction  'in' or 'out'
	 * @throws Exception  throw when query database
	 */
	public void process(String code, int idStation, String direction) throws Exception {
		
		if(direction.equals(Direction.in)) {
			controller.checkEmbarkation(code, idStation);
		}
		else if(direction.equals(Direction.out)) {
			controller.checkDisbarkation(code, idStation);
		};
		
		// open gate
		Gate.getInstance().open();
	}
	
	
}
