package controller.exception;

import entity.ticket.Ticket;

public class NotEnoughBalanceException extends RuntimeException{

	/**
	 * The NotEnoughBalanceException wraps all unchecked exceptions and enriches them with error code
	 * You can use this exception to inform not enough balance of customer of oneway ticket or card
	 */
	private static final long serialVersionUID = 1L;

	
	public NotEnoughBalanceException() {
		
	}
	
	public NotEnoughBalanceException(String message) {
		super(message);
	}
	
	public NotEnoughBalanceException(String message, Ticket ticket) {
		super(message + "\n\n" + ticket.getInfor());
	}
	
	@Override
	public String getMessage() {
		return super.getMessage();
	}

}
