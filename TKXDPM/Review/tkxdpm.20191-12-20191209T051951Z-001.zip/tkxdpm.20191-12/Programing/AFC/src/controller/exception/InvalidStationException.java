package controller.exception;

import entity.ticket.Ticket;

public class InvalidStationException  extends RuntimeException{
	
	/**
	 * The InvalidStationException wraps all unchecked exceptions and enriches them with error code
	 * You can use this exception to check entering or exiting station of oneway ticket of customer
	 */
	
	private static final long serialVersionUID = -146949103793302847L;
	
	
	public InvalidStationException() {
		
	}
	
	public InvalidStationException(String message) {
		super(message);
	}
	
	
	public InvalidStationException(String message, Ticket ticket) {
		super(message + "\n\n" + ticket.getInfor());
	}
	
	@Override
	public String getMessage() {
		return super.getMessage();
	}

}
