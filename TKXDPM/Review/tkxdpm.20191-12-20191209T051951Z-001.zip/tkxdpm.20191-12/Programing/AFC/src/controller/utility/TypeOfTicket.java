package controller.utility;

public enum TypeOfTicket {
	card,
	onewayticket,
	twentyfourhour
}
