package controller.utility;

public interface TicketStatus {
	int notUsed = 0;
	int inUsed = 1;
	int destroyed = 2;
}
