package controller.utility;

public interface BaseBalance {
	int card = 15000;
	int onewayTicket = 12000;
}
