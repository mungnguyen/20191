package controller.exception;

import java.util.Objects;

import entity.ticket.Ticket;

public class WrongDirectionException extends RuntimeException{

	/**
	 * The NotEnoughBalanceException wraps all unchecked exceptions and enriches them with error code
	 * You can use this exception to inform wrong direction of customers
	 */
	private static final long serialVersionUID = 4403539105272580846L;
	
	public WrongDirectionException() {
		
	}
	
	public WrongDirectionException(String message) {
		super(message);
	}
	
	public WrongDirectionException(String message, Ticket ticket) {
		super(message + "\n\n" + ticket.getInfor());
	}
	
	@Override
	public String getMessage() {
		return super.getMessage();
	}
	

}
