package controller.exception;

import entity.ticket.Ticket;

public class InvalidEmbarkationTimeException extends RuntimeException {
	
	/**
	 * The InvalidStationException wraps all unchecked exceptions and enriches them with error code 
	 * You can use this exception to inform invalid embarkation time of 24h ticket of customer
	 */
	
	private static final long serialVersionUID = 7414276587338010382L;
	
	
	public InvalidEmbarkationTimeException() {
		
	}
	
	public InvalidEmbarkationTimeException(String message) {
		super(message);
	}
	
	public InvalidEmbarkationTimeException(String message, Ticket ticket) {
		super(message + "\n\n" + ticket.getInfor());
	}
	
	@Override
	public String getMessage() {
		return super.getMessage();
	}

}
