package controller;

import java.util.Date;

import controller.exception.InvalidTicketException;
import controller.exception.WrongDirectionException;
import controller.utility.CalculatingCost;
import controller.utility.Direction;
import controller.utility.TicketStatus;
import controller.utility.Utility;
import entity.database.TwentyfourHourTicketDB;
import entity.ticket.Ticket;
import entity.ticket.TwentyfourHourTicket;
import entity.transaction.BuilderTransaction;


/**
 * @author le minh nguyen
 * Lecture: Nguyen Thi Thu Trang
 * Project: AFC
 * Date: Dec 6, 2019
 * Brief Description: process information related to twentyfour ticket
 */
public class TwentyfourHourController extends Controller {
	private static TwentyfourHourController instance;
	private TwentyfourHourTicketDB tfhticketdb;
	
	public TwentyfourHourController() throws Exception {
		this.tfhticketdb = TwentyfourHourTicketDB.getInstance();
	}
	
	public TwentyfourHourController(CalculatingCost cal) throws Exception {
		this.tfhticketdb = TwentyfourHourTicketDB.getInstance();
		this.cal = cal;
	}
	
	public static TwentyfourHourController getInstance(CalculatingCost cal) throws Exception {
		if (instance == null) {
			instance = new TwentyfourHourController(cal);
		}
		return instance;
	}
	
	@Override
	public Ticket getTicketInfor(String code) throws Exception {
		return this.tfhticketdb.getTicketInfor(code);
	}
	

	
	/**
	 * check if ticket is in used or destroyed
	 * @param tfhticket 24h ticket
	 */
	public void checkTime(TwentyfourHourTicket tfhticket){
		if (tfhticket.status == TicketStatus.notUsed) {
			tfhticket.setActiveTime(new Date());
			return;
		}
		
		Date current = new Date();
		if(current.getTime() - tfhticket.getActiveTime().getTime() > (24*3600*1000)) {
			Date expTime = new Date(tfhticket.getActiveTime().getTime() + (24*60*60*1000));
			throw new InvalidTicketException(String.format("your ticket has expired (validate to: %s)", expTime), tfhticket);
		}
		
		if (tfhticket.status == TicketStatus.destroyed) {
			throw new InvalidTicketException("invalid 24h ticket",tfhticket);
		}
	}

	@Override
	public void updateTicketInfor(Ticket ticket) throws Exception {
		TwentyfourHourTicket tfhTicket_ = (TwentyfourHourTicket) ticket;
		this.tfhticketdb.updateTicketInfor(tfhTicket_);
	}
	
	@Override
	public void checkEmbarkation(String code, int idStation) throws Exception {
		//get information and check time
		TwentyfourHourTicket tfhticket = (TwentyfourHourTicket) this.getTicketInfor(code);
		this.checkTime(tfhticket);	
		
		//check direction 
		if(tfhticket.direction.equals(Direction.out)) {
			throw new WrongDirectionException("just allow to out", tfhticket);
		}
		//set up new transaction
		Date time = new Date();
		this.transaction = new BuilderTransaction()
							.setId24hTicket(tfhticket.ID)
							.setEmbarkationTime(Utility.convertDateToString(time))
							.setEmbarkationStation(idStation)
							.build();
		
		//update ticket information
		tfhticket.status = TicketStatus.inUsed;
		tfhticket.direction = Direction.out;
		this.updateTicketInfor(tfhticket);
		
		//show ticket info
		tfhticket.showInfor();
		
		//create new transaction
		this.tfhticketdb.createTransaction(this.transaction);	
	}

	@Override
	public void checkDisbarkation(String code, int idStation) throws Exception {
		TwentyfourHourTicket tfhticket = (TwentyfourHourTicket) this.getTicketInfor(code);
		
		if(tfhticket.direction.equals(Direction.in)) {
			throw new WrongDirectionException("just allow to in", tfhticket);
		}
		
		Date time = new Date();
		transaction = tfhticketdb.getTransaction(tfhticket.ID);
		transaction = new BuilderTransaction()
						.setIdTransaction(transaction.getIdTransaction())
						.setId24hTicket(transaction.getId24hTicket())
						.setEmbarkationTime(transaction.getEmbarkationTime())
						.setDismbarkationTime(Utility.convertDateToString(time))
						.setEmbarkationStation(transaction.getEmbarkationStation())
						.setDisembarkationStation(idStation)
						.build();
		
		if (time.getTime() - tfhticket.getActiveTime().getTime() >= (24*3600*1000)) {
			tfhticket.status = TicketStatus.destroyed;
		}
		
		//show infor and update
		tfhticket.direction = Direction.in;
		this.updateTicketInfor(tfhticket);
		tfhticket.showInfor();

		//update transaction
		tfhticketdb.updateTransaction(transaction);
		
	}
	
}
