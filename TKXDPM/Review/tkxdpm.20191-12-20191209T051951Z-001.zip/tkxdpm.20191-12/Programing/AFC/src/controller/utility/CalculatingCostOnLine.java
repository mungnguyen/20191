/**
 * AFC
 * controller.utility
 * le minh nguyen
 * Dec 6, 2019
 */
package controller.utility;

import entity.database.OnewayTicketDB;
import entity.database.TicketDB;
import entity.station.Station;

/**
 * @author le minh nguyen
 * @version 1.0
 * Lecture: Nguyen Thi Thu Trang
 * Project: AFC
 * Date: Dec 6, 2019
 * Brief Description: 
 */
public class CalculatingCostOnLine implements CalculatingCost{
	
	private static CalculatingCostOnLine instance;
	
	public static CalculatingCostOnLine getInstance() {
		if (instance == null) {
			instance = new CalculatingCostOnLine();
		}
		return instance;
	}

	@Override
	public int calculateCost(int enterStation, int exitStation) throws Exception {
		Station station1 = TicketDB.getStation(enterStation);
		Station station2 = TicketDB.getStation(exitStation);
		double distance = Math.abs(station1.getDistance() - station2.getDistance());
		if (distance <= 5) {
			return 10000;
		}else {
			return 10000 + (int)Math.ceil((distance - 5)/2)*2000;
		}
	}
	
	public static void main(String[] args) throws Exception {
		OnewayTicketDB ow = OnewayTicketDB.getInstance();
		System.out.println(CalculatingCostOnLine.getInstance().calculateCost(3, 12));
	}

}
