package controller.utility;

public interface Direction {
	String in = "in";
	String out = "out";
}
