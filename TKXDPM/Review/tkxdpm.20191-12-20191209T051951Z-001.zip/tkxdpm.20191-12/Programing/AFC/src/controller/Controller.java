package controller;


import controller.utility.CalculatingCost;
import entity.database.CardDB;
import entity.database.OnewayTicketDB;
import entity.database.TicketDB;
import entity.database.TwentyfourHourTicketDB;
import entity.station.Station;
import entity.ticket.Ticket;
import entity.transaction.Transaction;

/**
 * Date: Nov 09-2019
 * This is parent controller which takes responsibility for defining general processing methods for all type of ticket
 * @author le minh nguyen
 * @version 1.0
 */


public abstract class Controller {
	
	
	/**
	 * this attribute represents for a transaction (or a trip) from station A to station B
	 */
	protected Transaction transaction;
	
	
	/**
	 * this attribute is instance of CalculateCost which takes responsibility for calculating fare
	 */
	protected CalculatingCost cal;
	
	
	/**
	 * this method gets information of ticket and assign to ticket attribute in subclass
	 * @param code code of ticket retrieved from hash barcode
	 * @return Ticket the ticket getting from database
	 * @throws Exception exception when query database
	 */
	public abstract Ticket getTicketInfor(String code) throws Exception;
	
	
	/**
	 * this method updates information of ticket
	 * @param ticket ticket after modifying infor
	 * @throws Exception when query data base
	 */
	public abstract void updateTicketInfor(Ticket ticket) throws Exception;
	
	
	/**
	 * this method checks information of ticket (as direction, balance, ...) whether to be valid or not when entering
	 * @param code code of the ticket after hashing
	 * @param idStation id of the station at time passenger enters
	 * @throws Exception when query data base
	 */
	public abstract void checkEmbarkation(String code, int idStation) throws Exception;
	
	
	/**
	 * this method checks information of ticket (as direction, balance, ...) whether to be valid or not when exiting
	 * @param code code code of the ticket after hashing
	 * @param idStation id of the station at time passenger enters
	 * @throws Exception when query data base
	 */
	public abstract void checkDisbarkation(String code, int idStation) throws Exception;
	
	
	/**
	 * this methods calculate fare between two station
	 * @param enterStation station where passenger has entered
	 * @param exitStation station where passenger has exitted
	 * @return cost between two station provided
	 * @throws Exception when query data base
	 */
	public int calculateCost(int enterStation, int exitStation) throws Exception {
		return this.cal.calculateCost(enterStation, exitStation);
	};
	
	
	/**
	 * list all valid tickets in database
	 * @throws Exception when query data base
	 */
	public static void showAllValidTicket() throws Exception {
		System.out.println("\n------------------------------- LIST OF TICKETS-------------------------------------");
		OnewayTicketDB.getInstance().showAllValidTicket();
		System.out.println();
		CardDB.getInstance().showAllValidTicket();
		System.out.println();
		TwentyfourHourTicketDB.getInstance().showAllValidTicket();
		System.out.println("---------------------------------------------------------------------------------------\n");
	}
}
