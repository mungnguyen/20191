/**
 * AFC
 * controller.utility
 * le minh nguyen
 * Dec 6, 2019
 */
package controller.utility;

/**
 * @author le minh nguyen
 * @version 1.0
 * Lecture: Nguyen Thi Thu Trang
 * Project: AFC
 * Date: Dec 6, 2019
 * Brief Description: calculate fare for passenger
 */
public interface CalculatingCost {
	
	/**
	 * this methods calculate fare between two station
	 * @param enterStation station when entering
	 * @param exitStation station when exiting
	 * @return cost between two station provided
	 * @throws Exception when query database
	 */
	public int calculateCost(int enterStation, int exitStation) throws Exception;
}
