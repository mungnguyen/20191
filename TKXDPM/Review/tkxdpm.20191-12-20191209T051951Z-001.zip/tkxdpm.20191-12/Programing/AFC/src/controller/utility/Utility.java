package controller.utility;

import java.io.File;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

import controller.exception.InvalidTicketException;
import entity.database.AFCDatabaseAccess;
import hust.soict.se.customexception.InvalidIDException;
import hust.soict.se.recognizer.TicketRecognizer;


/**
 * @author le minh nguyen
 * @version 1.0
 * Lecture: Nguyen Thi Thu Trang
 * Project: AFC
 * Date: Dec 6, 2019
 * Brief Description: provide useful function for system
 */
public class Utility {
	
	
	public Utility() {
		
	}
	
	public static String convertDateToString(Date date) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.format(date);
	}
	
	public static Date convertStringtoDate(String date) throws ParseException{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.parse(date);
	}
	
	
	/**
	 * This method gets barcode inputed from passenger then checks type of barcode
	 * @param barcode inputted by passengers
	 * @return TypeOfTicket type of the ticket
	 * @throws Exception when query database
	 */
	public static TypeOfTicket checkTypeOfTicket(String barcode) throws Exception {
		if (barcode.equals(barcode.toUpperCase())) {
			return TypeOfTicket.card;
		}else if (barcode.equals(barcode.toLowerCase())){
			String code = TicketRecognizer.getInstance().process(barcode);
			String sql = String.format("select idticket FROM (" +
					"select idonewayticket as idTicket, code from onewayticket " + 
					"union " + 
					"select id24hticket as idTicket, code from 24hticket " + 
					") as result " + 
					"where code = \"%s\";", code);
			Connection conn = AFCDatabaseAccess.getConnection();
			Statement stm = conn.createStatement();
			ResultSet res = stm.executeQuery(sql);
			if (res.next()) {
				String ticketCode = res.getString(1);
				if(ticketCode.startsWith("OW")) {
					return TypeOfTicket.onewayticket;
				}else {
					return TypeOfTicket.twentyfourhour;
				}
			}else {
				throw new InvalidTicketException("invalid ticket");
			}	
		}else {
			throw new InvalidIDException("invalid barcode");
		}
	}
	
	
	/**
	 * read barcode from file then checks and gets coressponding tickets
	 * @param file contains barcode
	 * @param type type of the ticket
	 * @return list of the tickets corespond to type provided
	 * @throws Exception when query database
	 */
	public static ArrayList<String> readTicketsFromFile(File file, TypeOfTicket type) throws Exception {
		ArrayList<String> lstTicket = new ArrayList<String>();
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(file);
		while (sc.hasNextLine()) {
			String barcode = sc.nextLine();
			if (Utility.checkTypeOfTicket(barcode) == type) {
				lstTicket.add(barcode);
			}
		}
		return lstTicket;
	}
	
	
	/**
	 * convert type of ticket from int to string
	 * @param type  type of the ticket in int format
	 * @return type of the ticket in string format
	 */
	public static String getStatusOfTicket(int type) {
		return type==0 ? "new" : (type == 1 ? "in used": "destroyed");
	}
	
	
}
