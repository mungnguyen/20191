package controller;

import java.util.Date;

import controller.exception.InvalidTicketException;
import controller.exception.NotEnoughBalanceException;
import controller.exception.WrongDirectionException;
import controller.utility.BaseBalance;
import controller.utility.CalculatingCost;
import controller.utility.Direction;
import controller.utility.TicketStatus;
import controller.utility.Utility;
import entity.database.CardDB;
import entity.ticket.Card;
import entity.ticket.Ticket;
import entity.transaction.BuilderTransaction;

public class CardController extends Controller {
	private CardDB cardDB;
	private static CardController instance;

	public CardController() throws Exception{
		this.cardDB = CardDB.getInstance();
	}


	private CardController(CalculatingCost cal) throws Exception{
		this.cardDB = CardDB.getInstance();
		this.cal = cal;
	}


	public static CardController getInstance(CalculatingCost cal) throws Exception {
		if (instance == null) {
			instance = new CardController(cal);
		}
		return instance;
	}

	@Override
	public Ticket getTicketInfor(String code) throws Exception {
		return this.cardDB.getTicketInfor(code);
	}

	@Override
	public void updateTicketInfor(Ticket ticket) throws Exception {
		Card updateCard = (Card) ticket;
		this.cardDB.updateTicketInfor(updateCard);
	}


	public void checkEnteringBalance(Card card) throws Exception {
		if(card.getBalance() < BaseBalance.card) {
			throw new NotEnoughBalanceException(String.format("not enough balance (expected: %d)", BaseBalance.card), card);
		}
	}

	public void checkEnterStation(Card card) throws Exception{
		//check direction
		if(card.direction.equals(Direction.out)) {
			throw new WrongDirectionException("The cua ban da duoc su dung de vao");
		}

		if(card.status == TicketStatus.destroyed) {
			throw new InvalidTicketException("The cua ban khong con gia tri su dung");
		}
	}

	public void checkExitStation(Card card) throws Exception{
		//check direction
		if(card.direction.equals(Direction.in)) {
			throw new WrongDirectionException("The cua ban da duoc su dung de ra");
		}

		if(card.status == TicketStatus.destroyed) {
			throw new InvalidTicketException("The cua ban khong con gia tri su dung");
		}
	}

	public void checkExitingBalance(Card card, int cost) throws Exception{
			if(card.getBalance() < cost) {
				throw new NotEnoughBalanceException(String.format("not enough balance (expected: %d)", cost), card);
			}
			card.setBalance(card.getBalance() - cost);
	}

	@Override
	public void checkEmbarkation(String code, int idStation) throws Exception {
		Card card = (Card) this.getTicketInfor(code);

		this.checkEnteringBalance(card);
		this.checkEnterStation(card);

		if(card.direction.equals(Direction.out)) {
			throw new WrongDirectionException("just allow to out", card);
		}

		//set up transaction
		Date time = new Date();
		this.transaction = new BuilderTransaction()
				.setIdCard(card.ID)
				.setEmbarkationTime(Utility.convertDateToString(time))
				.setEmbarkationStation(idStation)
				.build();

		//update ticket info
		card.direction = Direction.out;
		card.status = TicketStatus.inUsed;
		this.updateTicketInfor(card);
		card.showInfor();

		//update transaction
		this.cardDB.createTransaction(transaction);
	}

	@Override
	public void checkDisbarkation(String code, int idStation) throws Exception {
		Card card = (Card) this.getTicketInfor(code);

		//check if card doesnt have embarkation station, means direction is still in
		if(card.direction.equals(Direction.in)) {
			throw new WrongDirectionException("just allow to in", card);
		}
		//setup transaction
		transaction = cardDB.getTransaction(card.ID);
		Date currentTime = new Date();
		transaction = new BuilderTransaction()
				.setIdTransaction(transaction.getIdTransaction())
				.setIdOnewayTicket(transaction.getIdCard())
				.setEmbarkationTime(transaction.getEmbarkationTime())
				.setDismbarkationTime(Utility.convertDateToString(currentTime))
				.setEmbarkationStation(transaction.getEmbarkationStation())
				.setDisembarkationStation(idStation)
				.build();

		int cost = this.calculateCost(transaction.getEmbarkationStation(), transaction.getDisembarkationStation());
		this.checkExitingBalance(card, cost);

		//update card information
		card.direction = Direction.in;
		this.updateTicketInfor(card);
		card.showInfor();

		//updateTransaction
		cardDB.updateTransaction(transaction);

	}

	public static void main(String[] args) throws Exception {
		CardController cardCtr = new CardController();
		//cardCtr.checkEmbarkation("c439c1df0de4b008", 3);
		cardCtr.checkDisbarkation("c439c1df0de4b008", 6);
	}
}
