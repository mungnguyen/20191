package controller.exception;

import entity.ticket.Ticket;

public class InvalidTicketException extends RuntimeException{

	/**
	 * The InvalidStationException wraps all unchecked exceptions and enriches them with error code
	 * You can use this exception to inform the ticket has become invalid (due to be destroyed status)
	 */
	private static final long serialVersionUID = 1091337136123906298L;
	
	public InvalidTicketException() {
		
	}
	
	public InvalidTicketException(String message) {
		super(message);
	}
	
	public InvalidTicketException(String message, Ticket ticket) {
		super(message + "\n\n" + ticket.getInfor());
	}
	
	@Override
	public String getMessage() {
		return super.getMessage();
	}

}
