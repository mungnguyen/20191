package controller;

import java.util.Date;

import controller.exception.InvalidStationException;
import controller.exception.InvalidTicketException;
import controller.exception.NotEnoughBalanceException;
import controller.exception.WrongDirectionException;
import controller.utility.BaseBalance;
import controller.utility.CalculatingCost;
import controller.utility.Direction;
import controller.utility.TicketStatus;
import controller.utility.Utility;
import entity.database.OnewayTicketDB;
import entity.database.TicketDB;
import entity.ticket.OnewayTicket;
import entity.ticket.Ticket;
import entity.transaction.BuilderTransaction;


/**
 * @author le minh nguyen
 * Lecture: Nguyen Thi Thu Trang
 * Project: AFC
 * Date: Dec 6, 2019
 * Brief Description: process information related to oneway ticket
 */
public class OnewayController extends Controller{
	
	private static OnewayController instance;
	
	public OnewayController(CalculatingCost cal) throws Exception {
		this.cal = cal;
	}
	
	public OnewayController() {
		
	}
	
	public static OnewayController getInstance(CalculatingCost cal) throws Exception {
		if (instance == null) {
			instance = new OnewayController(cal);
		}
		return instance;
	}

	@Override
	public Ticket getTicketInfor(String code) throws Exception {
		return OnewayTicketDB.getInstance().getTicketInfor(code);
	}

	@Override
	public void updateTicketInfor(Ticket ticket) throws Exception {
		OnewayTicket ticket_ = (OnewayTicket) ticket;
		OnewayTicketDB.getInstance().updateTicketInfor(ticket_);
	}

	@Override
	public void checkEmbarkation(String code, int idStation) throws Exception {
		OnewayTicket onewayTicket = (OnewayTicket) this.getTicketInfor(code);
		this.checkEnterStation(onewayTicket, idStation);
		
		// create new transaction
		Date currentTime = new Date();
		this.transaction = new BuilderTransaction()
				.setIdOnewayTicket(onewayTicket.ID)
				.setEmbarkationTime(Utility.convertDateToString(currentTime))
				.setEmbarkationStation(idStation)
				.build();
			
		// update ticket information
		onewayTicket.direction = Direction.out;
		onewayTicket.status = TicketStatus.inUsed;
		OnewayTicketDB.getInstance().updateTicketInfor(onewayTicket);
		
		// show ticket infor
		onewayTicket.showInfor();
		
		// create new transaction
		OnewayTicketDB.getInstance().createTransaction(this.transaction);			
	}

	@Override
	public void checkDisbarkation(String code, int idStation) throws Exception {
		OnewayTicket onewayTicket = (OnewayTicket)this.getTicketInfor(code);
		this.checkExitStation(onewayTicket, idStation);
		
		// setup transaction
		this.transaction = OnewayTicketDB.getInstance().getTransaction(onewayTicket.ID);
		Date currentTime = new Date();
		this.transaction = new BuilderTransaction()
				.setIdTransaction(this.transaction.getIdTransaction())
				.setIdOnewayTicket(this.transaction.getIdOnewayTicket())
				.setEmbarkationTime(this.transaction.getEmbarkationTime())
				.setDismbarkationTime(Utility.convertDateToString(currentTime))
				.setEmbarkationStation(this.transaction.getEmbarkationStation())
				.setDisembarkationStation(idStation)
				.build();
		
		// check balance
		int balance = this.checkExitingBalance
				(onewayTicket, 
				this.transaction.getEmbarkationStation(), 
				this.transaction.getDisembarkationStation());
		onewayTicket.setBalance(balance);
		
		// update ticket information
		onewayTicket.direction = Direction.in;
		onewayTicket.status = TicketStatus.destroyed;
		OnewayTicketDB.getInstance().updateTicketInfor(onewayTicket);
		
		// update transaction
		OnewayTicketDB.getInstance().updateTransaction(transaction);
		

		// show ticket infor
		onewayTicket.showInfor();
		
		
	}

	
	/**
	 * check information of ticket at enter station
	 * @param onewayTicket oneway ticket object
	 * @param idStation id of the station
	 */
	public void checkEnterStation(OnewayTicket onewayTicket, int idStation) {
		// check direction
		if (onewayTicket.direction.equals(Direction.out)) {
			throw new WrongDirectionException("just allow to out", onewayTicket);
		}
		
		// check valid ticket
		if (onewayTicket.status == TicketStatus.destroyed) {
			throw new InvalidTicketException("invalid ticket", onewayTicket);
		}
		
		// check enter station
		int enterStation = onewayTicket.getEnterStation();
		int exitStation = onewayTicket.getExitStation();
		if (enterStation < exitStation) {
			if (idStation < enterStation || idStation > exitStation) {
				onewayTicket.showInfor();
				throw new InvalidStationException
				(String.format("invalid station (must between %d - %d (%s - %s))",
				enterStation, exitStation, TicketDB.getStation(enterStation).getName(), TicketDB.getStation(exitStation).getName()),
				onewayTicket);
			}
		}else {
			if (idStation > enterStation || idStation < exitStation) {
				onewayTicket.showInfor();
				throw new InvalidStationException
				(String.format("invalid station (must between %d - %d (%s - %s))",
				exitStation, enterStation, TicketDB.getStation(exitStation).getName(), TicketDB.getStation(enterStation).getName()),
				onewayTicket);
			}
		}
		
		// check balance
		if (onewayTicket.getBalance() < BaseBalance.onewayTicket) {
			onewayTicket.showInfor();
			throw new NotEnoughBalanceException(String.format("not enough balance (expected %d)", BaseBalance.onewayTicket), onewayTicket);
		}
	}
	
	
	/**
	 * check information of the ticket at exit station
	 * @param onewayTicket oneway ticket object
	 * @param idStation id of the station
	 */
	public void checkExitStation(OnewayTicket onewayTicket, int idStation){
		// check valid ticket
		if (onewayTicket.status == TicketStatus.destroyed) {
			throw new InvalidTicketException("invalid ticket", onewayTicket);
		}
		
		// check direction
		if (onewayTicket.direction.equals(Direction.in)) {
			throw new WrongDirectionException("just allow to in", onewayTicket);
		}
	}
	
	
	/**
	 * check balance when exiting station
	 * @param onewayTicket oneway ticket Object
	 * @param enterStation enter station
	 * @param exitStation exit station
	 * @return int the remained balance
	 * @throws Exception occurs when getting station
	 */
	public int checkExitingBalance(OnewayTicket onewayTicket, int enterStation, int exitStation) throws Exception {
		int cost = this.calculateCost(enterStation, exitStation);
		if (onewayTicket.getBalance() < cost) {
			throw new NotEnoughBalanceException(String.format("not enough balance (expected: %d)", cost), onewayTicket);
		}
		return onewayTicket.getBalance()-cost;
	}
	
}
