package entity.ticket;


/**
 * @author le minh nguyen
 * Lecture: Nguyen Thi Thu Trang
 * Project: AFC
 * Date: Dec 6, 2019
 * Brief Description: this class represents for ticket objects with basic information
 */
public abstract class Ticket {
	/**
	 * represents for identifying each of ticket
	 */
	public String ID;
	
	
	/**
	 * represents for direction of ticket currently ('in' or 'out')
	 */
	public String direction;
	
	
	/**
	 * represents for status of ticket currently ('not used', 'in used' or 'destroyed')
	 */
	public int status;
	
	
	/**
	 * show information of the ticket
	 */
	public abstract void showInfor();
	
	
	/**
	 * get information of the ticket
	 * @return String
	 */
	public abstract String getInfor();
	
	
	/**
	 * @param barcode the barcode inputted by passengers
	 * show information of the ticket in oneline
	 */
	public abstract void showInforInOneLine(String barcode);
}
