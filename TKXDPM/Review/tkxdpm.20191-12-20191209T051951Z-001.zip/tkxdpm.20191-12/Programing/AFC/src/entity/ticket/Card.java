package entity.ticket;


import controller.utility.Utility;

/**
 * @author Thanh Ng�n
 *
 */
public class Card extends Ticket {
	private double balance;

	public Card() {

	}

/**
 * @param id String
 * @param balance Double
 * @param status int (0 - not yet used, 1 - in used, 2 - destroyed)
 * @param direction String
 *
 */
	public Card(String id, double balance, int status, String direction) {
		this.ID = id;
		this.balance = balance;
		this.status = status;
		this.direction = direction;
	}

	@Override
	public void showInfor() {
		System.out.println("--------- Information of card ---------");
		System.out.println(String.format("ID: %s", this.ID));
		System.out.println(String.format("Status: %s", Utility.getStatusOfTicket(this.status)));
		System.out.println(String.format("Balance: %.0f", this.balance));
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public void showInforInOneLine(String barcode){
		System.out.printf(String.format("[Card] [barcode: %s] [balance: %.0f]\n", barcode, balance));
	}

	@Override
	public String getInfor() {
		String infor = "--------- Information of card --------- \n" ;
		infor += String.format("ID: %s \n", this.ID);
		infor += String.format("Status: %s \n", Utility.getStatusOfTicket(this.status));
		infor += String.format("Balance: %.0f \n", this.balance);
		return infor;
	}

}
