package entity.station;

/**
 * @author le minh nguyen
 * @version 1.0
 * Lecture: Nguyen Thi Thu Trang
 * Project: AFC
 * Date: Dec 6, 2019
 * Brief Description: this class represents for station objects with basic information
 */
public class Station {
	/**
	 * represents for identify each of station
	 */
	private int idStation;
	
	
	/**
	 * represents for name each of station
	 */
	private String name;
	
	/**
	 * represents for distance from base station each of station
	 */
	private double distance;
	
	
	public Station() {
		
	}
	
	public Station(int idStation, String name, double distance) {
		this.idStation = idStation;
		this.name = name;
		this.distance = distance;
	}
	

	public int getIdStation() {
		return idStation;
	}

	public void setIdStation(int idStation) {
		this.idStation = idStation;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}
	
	
}
