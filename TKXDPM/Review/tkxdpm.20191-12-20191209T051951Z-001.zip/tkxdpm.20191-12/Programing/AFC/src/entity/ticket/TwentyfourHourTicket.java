package entity.ticket;

import java.util.Date;

import controller.utility.Utility;

public class TwentyfourHourTicket extends Ticket {
	Date activeTime;
	
	public TwentyfourHourTicket() {
		
	}
	
	
	public TwentyfourHourTicket(String id, String direction, int status, Date activeTime) {
		this.ID = id;
		this.direction = direction;
		this.status = status;
		this.activeTime = activeTime;
	}
	
	
	@Override
	public void showInfor() {
		System.out.println("--------- Information of 24h ticket ---------");
		System.out.println(String.format("ID: %s", this.ID));
		System.out.println(String.format("Status: %s", Utility.getStatusOfTicket(this.status)));
		if (this.status != 0) {
			System.out.println("Active Time: " +  Utility.convertDateToString(this.activeTime));
			System.out.println("Expire Time: " + Utility.convertDateToString(new Date(this.activeTime.getTime() + 24*3600*1000)));
		}
	}
	
	
	//getter and setter of actived time
	public Date getActiveTime() {
		return activeTime;
	}
	public void setActiveTime(Date activeTime) {
		this.activeTime = activeTime;
	}
	
	
	@Override
	public void showInforInOneLine(String barcode) {
		if (status == 0) {
			System.out.println(String.format("[24h Ticket] [barcode: %s] [new]", barcode));
		}else if(status==1){
			Date expTime = new Date(activeTime.getTime() + (24*60*60*1000));
			if (new Date().getTime() - expTime.getTime() < 0){
				System.out.println(String.format("[24h Ticket] [barcode: %s] [in used] [valid to: %s]", barcode, Utility.convertDateToString(expTime)));
			}else {
				System.out.println(String.format("[24h Ticket] [barcode: %s] [expired at %s]", barcode, Utility.convertDateToString(expTime)));
			}
		}
		
	}
	
	
	@Override
	public String getInfor() {
		String infor = "--------- Information of 24h ticket ---------\n";
		infor += String.format("ID: %s \n", this.ID);
		infor += String.format("Status: %s \n", Utility.getStatusOfTicket(this.status));
		if (this.status != 0) {
			infor += "Active Time: " +  Utility.convertDateToString(this.activeTime) + "\n";
			infor += "Expire Time: " + Utility.convertDateToString(new Date(this.activeTime.getTime() + 24*3600*1000)) + "\n";
		}
		return infor;
	}
	
}
