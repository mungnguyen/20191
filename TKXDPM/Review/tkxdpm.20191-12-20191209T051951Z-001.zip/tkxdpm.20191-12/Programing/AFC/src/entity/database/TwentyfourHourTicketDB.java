package entity.database;

import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;

import controller.exception.InvalidTicketException;
import controller.utility.TicketStatus;
import controller.utility.TypeOfTicket;
import controller.utility.Utility;
import entity.ticket.Ticket;
import entity.ticket.TwentyfourHourTicket;
import entity.transaction.BuilderTransaction;
import entity.transaction.Transaction;
import hust.soict.se.recognizer.TicketRecognizer;

public class TwentyfourHourTicketDB extends TicketDB {	
	
	private static TwentyfourHourTicketDB instance;
	
	public static TwentyfourHourTicketDB getInstance() throws Exception{
		if(instance == null) {
			instance = new TwentyfourHourTicketDB();
		}
		return instance;
	}
	
	public TwentyfourHourTicketDB() throws Exception {
		Connection conn = AFCDatabaseAccess.getConnection();
		stm = conn.createStatement();
	}
	

	@Override
	public void updateTicketInfor(Ticket ticket) throws SQLException {
		TwentyfourHourTicket tfhticket = (TwentyfourHourTicket) ticket;
		String sql = "update 24hticket set "
					+ "direction=" + "\"" + tfhticket.direction+"\","
					+ "status=" + "\"" + tfhticket.status +"\","
					+ "activeTime=" + "\"" + Utility.convertDateToString(tfhticket.getActiveTime())+ "\" "
					+ "where id24hTicket=" + "\"" + tfhticket.ID+"\";";
		stm.executeUpdate(sql);
	}

	@Override
	public Ticket getTicketInfor(String code) throws Exception {
		res = stm.executeQuery("select * from 24hticket where code="+ "\"" +code +"\";");
		if(res.next()) {
			String id = res.getString(1);
			String direction = Objects.toString(res.getString(3), "");
			Date activeTime = Utility.convertStringtoDate(Objects.toString(res.getString(4), "0000-00-00 00:00:00"));
			int status = res.getInt(5);
			return new TwentyfourHourTicket(id, direction, status, activeTime);
		}
		else {
			throw new InvalidTicketException("not found ticket");
		}
	}

	@Override
	public Transaction getTransaction(String idTicket) throws Exception {
		String sql = "select t1.* from transaction t1 " + 
				"where t1.idTransaction = (" + 
				"select max(t2.idTransaction) " + 
				"from transaction t2 " + 
				"where t2.id24hTicket =" + "\"" + idTicket+ "\");";
		this.res = stm.executeQuery(sql);
		this.res.next();
		int idTrans = this.res.getInt(1);
		String idTicket_ = this.res.getString(2);
		String embarkationTime = Objects.toString(this.res.getString(5), "");
		int embarkationstation = this.res.getInt(7);
		Transaction transaction = new BuilderTransaction()
				.setIdTransaction(idTrans)
				.setId24hTicket(idTicket_)
				.setEmbarkationTime(embarkationTime)
				.setEmbarkationStation(embarkationstation)
				.build();
		return transaction;
	}

	@Override
	public void createTransaction(Transaction transaction) throws Exception {
		String sql = "INSERT INTO transaction (id24hTicket, embarkationTime, embarkationStation) VALUES "
				+ String.format("(\"%s\", \"%s\", %d);" , transaction.getId24hTicket(), transaction.getEmbarkationTime(), transaction.getEmbarkationStation());
		stm.execute(sql);
	}

	@Override
	public void updateTransaction(Transaction transaction) throws Exception {
		String sql = "UPDATE transaction SET " 
				+ String.format("disembarkationTime=\"%s\", disembarkationStation=%d ", transaction.getDisembarkationTime(), transaction.getDisembarkationStation())
				+ String.format("WHERE idTransaction=%d;", transaction.getIdTransaction());
		stm.execute(sql);
	}
	
	@Override
	public void showAllValidTicket() throws Exception {
		ArrayList<String> lstBarcodeOw = Utility.readTicketsFromFile(new File("data\\ticket"), 
				TypeOfTicket.twentyfourhour);
		for (String barcode : lstBarcodeOw) {
			TwentyfourHourTicket tfTicket = (TwentyfourHourTicket) this.getTicketInfor(TicketRecognizer.getInstance().process(barcode));
			
			if (tfTicket.status == TicketStatus.notUsed) {
				tfTicket.showInforInOneLine(barcode);
			}else {
				Date current = new Date();
//				if (tfTicket.status == TicketStatus.inUsed && 
//						((current.getTime() - tfTicket.getActiveTime().getTime()) <= (24*60*60*1000))) {
//					tfTicket.showInforInOneLine(barcode);
//				}
				
				if (tfTicket.status == TicketStatus.inUsed) {
					tfTicket.showInforInOneLine(barcode);
				}
			}
		}
	}
}
