package entity.database;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Objects;

import controller.exception.InvalidTicketException;
import controller.utility.TicketStatus;
import controller.utility.TypeOfTicket;
import controller.utility.Utility;
import entity.ticket.OnewayTicket;
import entity.ticket.Ticket;
import entity.transaction.BuilderTransaction;
import entity.transaction.Transaction;
import hust.soict.se.recognizer.TicketRecognizer;

public class OnewayTicketDB extends TicketDB{
	
	private static OnewayTicketDB instance;
	
	
	public static OnewayTicketDB getInstance() throws Exception {
		if (instance == null) {
			instance = new OnewayTicketDB();
		}
		return instance;
	}
	
	
	private OnewayTicketDB() throws Exception {
		this.stm = AFCDatabaseAccess.getConnection().createStatement();
	}
	

	@Override
	public void updateTicketInfor(Ticket ticket) throws SQLException {
		OnewayTicket ticket_ = (OnewayTicket)ticket;
		this.stm.executeUpdate("update onewayticket set "
				+ "direction=" + "\"" + ticket_.direction + "\", "
				+ "balance=" + "\"" + ticket_.getBalance() + "\", "
				+ "status=" + "\"" + ticket_.status + "\" "
				+ "where idOnewayTicket=" + "\"" + ticket_.ID + "\";");
	}
	

	@Override
	public Ticket getTicketInfor(String code) throws Exception {
		
		this.res = this.stm.executeQuery("select * from onewayticket where code=" +  "\"" + code + "\";");
		if (this.res.next()) {
			String id = this.res.getString(1);
			String direction = Objects.toString(this.res.getString(3), "");
			int balance = this.res.getInt(4);
			int status = this.res.getInt(5);
			int enterStation = this.res.getInt(6);
			int exitStation = this.res.getInt(7);
			return new OnewayTicket(id, direction, balance, status, enterStation, exitStation);	
		}else {
			throw new InvalidTicketException("invalid oneway ticket");	
		}
	}
	

	@Override
	public Transaction getTransaction(String idOneway) throws Exception {
		String sql = "select t1.* from transaction t1 " + 
				"where t1.idTransaction = (" + 
				"select max(t2.idTransaction) " + 
				"from transaction t2 " + 
				"where t2.idOnewayTicket =" + "\"" + idOneway + "\");";
		this.res = stm.executeQuery(sql);
		this.res.next();
		int idTrans = this.res.getInt(1);
		String idTicket_ = this.res.getString(3);
		String embarkationTime = Objects.toString(this.res.getString(5), "") ;
		int embarkationStation = this.res.getInt(7);
		Transaction transaction = new BuilderTransaction()
				.setIdTransaction(idTrans)
				.setIdOnewayTicket(idTicket_)
				.setEmbarkationTime(embarkationTime)
				.setEmbarkationStation(embarkationStation)
				.build();
		return transaction;
	}

	
	@Override
	public void createTransaction(Transaction transaction) throws Exception {
		String sql = "INSERT INTO transaction (idOnewayTicket, embarkationTime, embarkationStation) VALUES "
				+ String.format("(\"%s\", \"%s\", %d);", transaction.getIdOnewayTicket(), transaction.getEmbarkationTime(), transaction.getEmbarkationStation());
		stm.execute(sql);
	}

	
	@Override
	public void updateTransaction(Transaction transaction) throws Exception {
		String sql = "UPDATE transaction SET "
				+ String.format("disembarkationTime=\"%s\", disembarkationStation=%d ", transaction.getDisembarkationTime(), transaction.getDisembarkationStation())
				+ String.format("WHERE idTransaction=%d;", transaction.getIdTransaction());
		stm.executeUpdate(sql);
	}
	
	
	@Override
	public void showAllValidTicket() throws Exception {
		ArrayList<String> lstBarcodeOw = Utility.readTicketsFromFile(new File("data\\ticket"), 
				TypeOfTicket.onewayticket);
		for (String barcode : lstBarcodeOw) {
			OnewayTicket onewayTicket = (OnewayTicket) this.getTicketInfor(TicketRecognizer.getInstance().process(barcode));
//			if (onewayTicket.status != TicketStatus.destroyed) {
//				onewayTicket.showInforInOneLine(barcode);
//			}
			onewayTicket.showInforInOneLine(barcode);
		}
	}

}
