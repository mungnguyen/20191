package entity.database;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import controller.exception.InvalidStationException;
import entity.station.Station;
import entity.ticket.Ticket;
import entity.transaction.Transaction;

/**
 * 
 * @author le minh nguyen
 * Lecture: Nguyen Thi Thu Trang
 * Project: AFC
 * Date: Dec 6, 2019
 * Brief Description: takes reposibility for manupulating with databases which contain information of tickets
 */
public abstract class TicketDB {
	public Statement stm;
	public ResultSet res;
	public static List<Station> lstStation;
	
	/**
	 * This constructor initializes and set value for list of stations
	 * @throws Exception occurs when querying database
	 */
	public TicketDB() throws Exception {
		TicketDB.setAllStation();
	}
	
    /**
     * this method updates information of specific ticket into database
     * @param ticket the ticket after updating infor
     * @throws SQLException occurs when updating into database
     */
    public abstract void updateTicketInfor(Ticket ticket) throws SQLException;
    
    
    /**
     * this method gets information of ticket from database with code of ticket passed to method
     * @param code code of the ticket
     * @return Ticket
     * @throws Exception occurs when getting infor
     */
    public abstract Ticket getTicketInfor(String code) throws Exception;
    
    
    /**
     * this method gets information of transaction of ticket from database with idTicket passed to method
     * @param idTicket id of the ticket
     * @return Transaction Object
     * @throws Exception occurs when getting transaction
     */
    public abstract Transaction getTransaction(String idTicket) throws Exception;
    
    
	/**
	 * this method creates new transaction of the ticket
	 * @param transaction new one transaction
	 * @throws Exception occurs when creating new transaction in database
	 */
	public abstract void createTransaction(Transaction transaction) throws Exception;
	
	
	/**
	 * this method updates information of specific transaction
	 * @param transaction updated transaction
	 * @throws Exception occurs when updating transaction
	 */
	public abstract void updateTransaction(Transaction transaction) throws Exception;
	
	
	/**
	 * this method show all invalid tickets in database
	 * @throws Exception when getting ticket infor
	 */
	public abstract void showAllValidTicket() throws Exception;
	
	
	/**
	 * this method finds and returns a specific Station by id
	 * @param id id of the station
	 * @return Station Object
	 */
	public static Station getStation(int id) {
		for (Station station : TicketDB.lstStation) {
			if (station.getIdStation() == id) {
				return station;
			}
		}
		throw new InvalidStationException("invalid input station (must between 1-12)");
	}
	
	
	/**
	 * this method sets all station found in station database
	 * @throws Exception occurs when getting connection
	 */
	public static void setAllStation () throws Exception {
		String sql = "SELECT * FROM station";
		Statement stm = AFCDatabaseAccess.getConnection().createStatement();
		ResultSet res = stm.executeQuery(sql);
		List<Station> lstStation = new ArrayList<Station>();
		while(res.next()) {
			int id = res.getInt(1);
			String name = res.getString(2);
			double distance = res.getDouble(3);
			lstStation.add(new Station(id, name, distance));
		}
		TicketDB.lstStation =  lstStation;
	}
	
	/**
	 * shows all station in database
	 * @throws Exception occurs when getting stations in database
	 */
	public static void showAllStation() throws Exception {
		String sql="SELECT * FROM station";
		Statement stm = AFCDatabaseAccess.getConnection().createStatement();
		ResultSet res = stm.executeQuery(sql);
		int ID; String name;
		System.out.println("-------------- LIST OF STATIONS -----------------");
		while(res.next()) {
			ID = res.getInt(1);
			name = res.getString(2);
			System.out.println(String.format("%d - %s", ID, name));
		}
	}
	
	
	
}
