package entity.transaction;

/**
 * @author le minh nguyen
 * @version 1.0
 * Lecture: Nguyen Thi Thu Trang
 * Project: AFC
 * Date: Dec 6, 2019
 * Brief Description: this class represents for transaction objects created or updated after customer entering or exiting station successfully
 */

public class Transaction {
	private int idTransaction;
	private String idOnewayTicket;
	private String id24hTicket;
	private String idCard;
	private String embarkationTime;
	private String disembarkationTime;
	private int embarkationStation;
	private int disembarkationStation;
	
	public Transaction() {
		
	}
	
	public Transaction(int idTransaction, String idOnewayTicket, String id24hTicket, String idCard,
			String embarkationTime, String disbarkationTime, int embarktionStation, int disbarkationStation) {
		
		this.idTransaction = idTransaction;
		this.idOnewayTicket = idOnewayTicket;
		this.id24hTicket = id24hTicket;
		this.idCard = idCard;
		this.embarkationTime = embarkationTime;
		this.disembarkationTime = disbarkationTime;
		this.embarkationStation = embarktionStation;
		this.disembarkationStation = disbarkationStation;
	}
	
	
	/**
	 * show information of a trip
	 */
	public void showInfor() {
		String idTicket = this.id24hTicket != null ? this.id24hTicket : null;
		idTicket = this.idOnewayTicket != null ? this.idOnewayTicket : null;
		idTicket = this.idCard != null ? this.idCard : null;
		System.out.println(String.format("---------------Thong tin chuyen di %d -------------", this.idTransaction));
		System.out.println(String.format("ID ve: %s", idTicket));
		System.out.println(String.format("Tram vao: %d", this.embarkationStation));
		System.out.println(String.format("Tram ra: %d", this.disembarkationStation));
		System.out.println(String.format("Thoi gian vao: %s", this.embarkationTime));
		System.out.println(String.format("Thoi gian ra: %s", this.disembarkationTime));
	}

	public int getIdTransaction() {
		return idTransaction;
	}

	public String getIdOnewayTicket() {
		return idOnewayTicket;
	}

	public String getId24hTicket() {
		return id24hTicket;
	}

	public String getIdCard() {
		return idCard;
	}

	public String getEmbarkationTime() {
		return embarkationTime;
	}

	public String getDisembarkationTime() {
		return disembarkationTime;
	}

	public int getEmbarkationStation() {
		return embarkationStation;
	}

	public int getDisembarkationStation() {
		return disembarkationStation;
	}
	
	
}
