package entity.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Date: Nov 09-2019
 * this class takes responsibility for connecting to database
 * @author le minh nguyen
 * @version 1.0
 */
public class AFCDatabaseAccess {
	private static Connection connection = null;
	
    private AFCDatabaseAccess() {
		
	}
	
	/**
	 * This method checks whether connection with database has been created or not
	 * if not then creates a new one, else returns current connection
	 * @return Connection connection to database (construct only once)
	 * @throws Exception occurs when connecting to database
	 */
	public static Connection getConnection() throws Exception{
		if (connection != null) {
			return connection;
		}else {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				connection = DriverManager.getConnection("jdbc:mysql://localhost/afc?zeroDateTimeBehavior=convertToNull&user=root&password=");
			} catch (SQLException e) {
				System.out.println("SQL exception: " + e.getMessage());
			}
			return connection;
		}
		
	}
	
	/**
	 * This method takes responsibility for closing connection 
	 * when it doesn't need to use furthermore
	 */
	public void close() {
		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	
}
