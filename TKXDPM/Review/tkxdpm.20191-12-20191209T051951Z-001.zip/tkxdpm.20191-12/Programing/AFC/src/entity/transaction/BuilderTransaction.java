package entity.transaction;

/**
 * @author le minh nguyen
 * @version 1.0
 * Lecture: Nguyen Thi Thu Trang
 * Project: AFC
 * Date: Dec 6, 2019
 * Brief Description: this class uses Builder design pattern, which helps to build each of transaction step by step
 */
public class BuilderTransaction {
	private int idTransaction;
	private String idOnewayTicket;
	private String id24hTicket;
	private String idCard;
	private String embarkationTime;
	private String disembarkationTime;
	private int embarkationStation;
	private int disembarkationStation;
	
	public BuilderTransaction setIdTransaction(int idTrans) {
		this.idTransaction = idTrans;
		return this;
	}
	
	public BuilderTransaction setIdOnewayTicket(String idOnewayTicket) {
		this.idOnewayTicket = idOnewayTicket;
		return this;
	}
	
	public BuilderTransaction setId24hTicket(String id24hTicket) {
		this.id24hTicket = id24hTicket;
		return this;
	}
	
	public BuilderTransaction setIdCard(String idCard) {
		this.idCard = idCard;
		return this;		
	}
	
	public BuilderTransaction setEmbarkationTime(String embarkationTime) {
		this.embarkationTime = embarkationTime;
		return this;
	}
	
	public BuilderTransaction setDismbarkationTime(String disembarkationTime) {
		this.disembarkationTime = disembarkationTime;
		return this;
	}
	
	public BuilderTransaction setEmbarkationStation(int embarkationStation) {
		this.embarkationStation = embarkationStation;
		return this;
	}
	
	public BuilderTransaction setDisembarkationStation(int disembarkationStation) {
		this.disembarkationStation = disembarkationStation;
		return this;
	}
	
	public Transaction build() {
		return new Transaction(idTransaction, 
				idOnewayTicket, id24hTicket, idCard, 
				embarkationTime, disembarkationTime, 
				embarkationStation, disembarkationStation);
	}
	
	
}
