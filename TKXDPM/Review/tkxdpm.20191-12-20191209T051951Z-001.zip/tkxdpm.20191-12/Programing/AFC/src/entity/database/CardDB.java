package entity.database;

import java.io.File;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Objects;

import controller.exception.InvalidTicketException;
import controller.utility.TicketStatus;
import controller.utility.TypeOfTicket;
import controller.utility.Utility;
import entity.ticket.Card;
import entity.ticket.Ticket;
import entity.transaction.BuilderTransaction;
import entity.transaction.Transaction;
import hust.soict.se.scanner.CardScanner;


public class CardDB extends TicketDB{
	
	private static CardDB instance;
	
	public static CardDB getInstance() throws Exception{
		if(instance == null) {
			instance = new CardDB();
		}
		return instance;
	}
	public CardDB() throws Exception {
		Connection conn = AFCDatabaseAccess.getConnection();
		stm = conn.createStatement();
	}
	
	
	@Override
	public void updateTicketInfor(Ticket ticket) throws SQLException {
		Card card = (Card) ticket;
		stm.executeUpdate("update card set " 
				+ "direction=" + "\"" + card.direction + "\","
				+ "balance=" + "\"" + card.getBalance() + "\","
				+ "status=" + "\"" + card.status + "\" "
				+ "where idCard=" + "\"" + card.ID + "\";"
		);
	}

	
	@Override
	public Ticket getTicketInfor(String code) throws Exception {
		res = stm.executeQuery("select * from card where code="+ "\""+ code + "\";");
		if(res.next()) {
			String id = res.getString(1);
			String direction = Objects.toString(res.getString(3), "");
			double balance = res.getDouble(4);
			int status = res.getInt(5);
			return new Card(id, balance, status, direction);
		} else {
			throw new InvalidTicketException("invalid card");
		}
	}
	
	
	@Override
	public Transaction getTransaction(String idCard) throws Exception {
		String sql = "select t1.* from transaction t1 " + 
				"where t1.idTransaction = (" + 
				"select max(t2.idTransaction) " + 
				"from transaction t2 " + 
				"where t2.idCard =" + "\"" + idCard+ "\");";
		this.res = stm.executeQuery(sql);
		this.res.next();
		int idTrans = this.res.getInt(1);
		String idCard_ = this.res.getString(4);
		String embarkationTime = Objects.toString(this.res.getString(5), "") ;
		int embarkationStation = this.res.getInt(7);
		Transaction transaction = new BuilderTransaction()
				.setIdTransaction(idTrans)
				.setIdOnewayTicket(idCard_)
				.setEmbarkationTime(embarkationTime)
				.setEmbarkationStation(embarkationStation)
				.build();
		return transaction;
	}
	
	
	@Override
	public void createTransaction(Transaction transaction) throws Exception {
		String sql = "INSERT INTO transaction (idCard, embarkationTime, embarkationStation) VALUES "
				+ String.format("(\"%s\", \"%s\", %d);", transaction.getIdCard(), transaction.getEmbarkationTime(), transaction.getEmbarkationStation());
		stm.execute(sql);
		
	}
	
	
	@Override
	public void updateTransaction(Transaction transaction) throws Exception {
		String sql = "UPDATE transaction SET "
				+ String.format("disembarkationTime=\"%s\", disembarkationStation=%d ", transaction.getDisembarkationTime(), transaction.getDisembarkationStation())
				+ String.format("WHERE idTransaction=%d;", transaction.getIdTransaction());
		stm.executeUpdate(sql);
	}
	
	
	@Override
	public void showAllValidTicket() throws Exception {
		ArrayList<String> lstBarcodeOw = Utility.readTicketsFromFile(new File("data\\ticket"), 
				TypeOfTicket.card);
		for (String barcode : lstBarcodeOw) {
			Card card = (Card) this.getTicketInfor(CardScanner.getInstance().process(barcode));
//			if (card.status != TicketStatus.destroyed) {
//				card.showInforInOneLine(barcode);
//			}
			card.showInforInOneLine(barcode);
		}
	}
}
