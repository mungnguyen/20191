package entity.ticket;

import controller.utility.Utility;
import entity.database.TicketDB;

public class OnewayTicket extends Ticket{
	private int balance;
	private int enterStation;
	private int exitStation;
	
	public OnewayTicket() {
		
	}
	
	
	/**
	 * @param ID String
	 * @param direction String
	 * @param balance int
	 * @param status int (0-not yet used, 1-in used, 2-destroyed)
	 * @param enterStation int
	 * @param exitStation int
	 */
	public OnewayTicket(String ID, String direction, int balance, int status, int enterStation, int exitStation) {
		this.ID = ID;
		this.direction = direction;
		this.status = status;
		this.setBalance(balance);
		this.setEnterStation(enterStation);
		this.setExitStation(exitStation);
	}
	
	
	@Override
	public void showInfor() {
		System.out.println("\n---------- Information of oneway ticket ---------");
		System.out.println(String.format("ID: %s", this.ID));
		System.out.println(String.format("Balance: %d", this.balance));
		System.out.println(String.format("Status: %s", Utility.getStatusOfTicket(this.status)));
		System.out.println(String.format("EnterStation: %d (%s)", this.enterStation, TicketDB.getStation(this.enterStation).getName()));
		System.out.println(String.format("ExitStation: %d (%s)", this.exitStation, TicketDB.getStation(this.exitStation).getName()));
		System.out.println("--------------------------------------------------");
	}
	
	
	@Override
	public void showInforInOneLine(String barcode) {
		System.out.printf(String.format("[Oneway Ticket] [barcode: %s] %-11s from  %-10s to  %-12s (%d - %d)\n",
				barcode, "[" + (status == 0 ? "new": (status == 1 ? "in used":"destroyed")) + "]",
				TicketDB.getStation(enterStation).getName(), 
				TicketDB.getStation(exitStation).getName(),
				enterStation, exitStation));
	}
	
	
	@Override
	public String getInfor() {
		String infor = "\n----------Information of oneway ticket---------\n";
		infor += String.format("ID: %s \n", this.ID);
		infor += String.format("Balance: %d \n", this.balance);
		infor += String.format("Status: %s \n", Utility.getStatusOfTicket(this.status));
		infor += String.format("EnterStation: %d (%s) \n", this.enterStation, TicketDB.getStation(this.enterStation).getName());
		infor += String.format("ExitStation: %d (%s) \n", this.exitStation, TicketDB.getStation(this.exitStation).getName());
		infor += "-----------------------------------------\n";
		return infor;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public int getEnterStation() {
		return enterStation;
	}

	public void setEnterStation(int enterStation) {
		this.enterStation = enterStation;
	}

	public int getExitStation() {
		return exitStation;
	}

	public void setExitStation(int exitStation) {
		this.exitStation = exitStation;
	}

}
