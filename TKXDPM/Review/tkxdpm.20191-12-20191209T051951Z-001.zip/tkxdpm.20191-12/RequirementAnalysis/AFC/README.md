# TKXDPM.20191-12

## Danh sách các usecase

|Số thứ tự	|Tên usecase			|Mô tả	|
|	:----:	|	:----------------:	|:----- |
|1			|kiểm tra thẻ			|		|
|2			|kiểm tra thẻ vào		|		|
|3			|kiểm tra thẻ ra		|		|
|4			|kiểm tra vé vào		|		|
|5			|kiểm tra vé 24h vào	|		|
|6			|kiểm tra vé một lần vào|		|
|7			|kiểm tra vé ra			|		|
|8			|kiểm tra vé 24h ra		|		|
|9			|kiểm tra vé một lần ra	|		|





## Phân công công việc cho các thành viên:



### Công việc 1: đặc tả các usecase hệ thống AFC

|Tên thành viên				|Vẽ luồng sự kiện cho|
|---------------------------|--------------------|
|Nilanhdone  Phetmanivong	|	usecase 5,8	 |
|Lưu Thị Thanh Ngân			|	usecase 1,2,3	 |
|Nguyễn Chính Phú			|	không làm  		 |
|Lê Minh Nguyễn				|	usecase 4,6,7,9	 |
|							|					 |


### Công việc 2: Vẽ sơ đồ tuần tự và sơ đồ lớp cho các usecase
|Tên thành viên				|Vẽ luồng sự kiện cho|
|---------------------------|--------------------|
|Nilanhdone  Phetmanivong	|	usecase 5, 8	 |
|Lưu Thị Thanh Ngân			|	usecase 1,2,3	 |
|Nguyễn Chính Phú			|	usecase 9 (không làm)|
|Lê Minh Nguyễn				|	usecase 6,9	 	 |			


### Công việc 3: Từ điển thuật ngữ và đặc tả bổ sung

#### **Cả nhóm cùng làm**


### Công việc 4: Phân công review

|Người review				|Người được review	 |
|---------------------------|--------------------|
|Nilanhdone  Phetmanivong	|Lưu Thị Thanh Ngân	 |
|Lưu Thị Thanh Ngân			|Nguyễn Chính Phú	 |
|Nguyễn Chính Phú			|Lê Minh Nguyễn		 |
|Lê Minh Nguyễn				|Nilanhdone  Phetmanivong|
|							|					 |
