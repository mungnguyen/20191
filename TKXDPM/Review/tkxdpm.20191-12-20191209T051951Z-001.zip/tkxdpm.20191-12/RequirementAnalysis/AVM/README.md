# TKXDPM.20191-12

## Danh sách các usecase

|Số thứ tự	|Tên usecase	|Mô tả	|
|	:----:	|	:----:		|		|
|1			|tìm thông tin vé|		|
|2			|mua vé 24h		|		|
|3			|mua vé 1 lần	|		|
|4			|nạp tiền vào thẻ|		|
|5			|kiểm tra số dư	|		|
|6			|mua thẻ		|		|
|7			|thanh toán		|		|




## Phân công công việc cho các thành viên:



### Công việc 1: Vẽ luồng sự kiện cho các usecase trong hệ thống AVM

|Tên thành viên				|Vẽ luồng sự kiện cho|
|---------------------------|--------------------|
|Nilanhdone  Phetmanivong	|		usecase 1	 |
|Lưu Thị Thanh Ngân			|		usecase 2,3	 |
|Nguyễn Chính Phú			|		usecase 4,5	 |
|Lê Minh Nguyễn				|		usecase 6,7	 |
|							|					 |

### Công việc 2: Phân công review

|Người review				|Người được review	 |
|---------------------------|--------------------|
|Nilanhdone  Phetmanivong	|Lưu Thị Thanh Ngân	 |
|Lưu Thị Thanh Ngân			|Nguyễn Chính Phú	 |
|Nguyễn Chính Phú			|Lê Minh Nguyễn		 |
|Lê Minh Nguyễn				|Nilanhdone  Phetmanivong|
|							|					 |