# TKXDPM.20191-12

## Danh sách các usecase

|Số thứ tự	|Tên usecase			|Mô tả	|
|	:----:	|	:----------------:	|:----- |
|1			|kiểm tra thẻ			|		|
|2			|kiểm tra thẻ vào		|		|
|3			|kiểm tra thẻ ra		|		|
|4			|kiểm tra vé vào		|		|
|5			|kiểm tra vé 24h vào	|		|
|6			|kiểm tra vé một lần vào|		|
|7			|kiểm tra vé ra			|		|
|8			|kiểm tra vé 24h ra		|		|
|9			|kiểm tra vé một lần ra	|		|



## Phân công công việc cho các thành viên:



### Công việc 1: Vẽ lớp chi tiết và đặc tả lớp

|Tên thành viên				|Vẽ luồng sự kiện cho|
|---------------------------|--------------------|
|Nilanhdone  Phetmanivong	|	usecase 5, 8	 |
|Lưu Thị Thanh Ngân			|	usecase 1,2,3	 |
|Lê Minh Nguyễn				|	usecase 4,6,7,9  |			


### Công việc 2: Vẽ màn hình giao diện

|Tên thành viên				|Vẽ màn hình         |
|---------------------------|--------------------|
|Nilanhdone  Phetmanivong	|	24hticket, Home, Invalid24hTicket	 |
|Lưu Thị Thanh Ngân			|	Choosestaion, InvalidPrepaidCard, PrepaidCard	 |
|Lê Minh Nguyễn				|	OnewayTicket, InvalidOnewayTicket, TransactionScreen  |	


### Công việc 3: Thiết kế cơ sở dữ liệu

*Cả nhóm cùng làm*


### Công việc 4: Phân công review

|Người review				|Người được review	 |
|---------------------------|--------------------|
|Nilanhdone  Phetmanivong	|Lưu Thị Thanh Ngân	 |
|Lưu Thị Thanh Ngân			|Lê Minh Nguyễn    	 |
|Lê Minh Nguyễn				|Nilanhdone  Phetmanivong|
